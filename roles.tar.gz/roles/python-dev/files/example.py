#!/usr/bin/pyt

if __name__ == "__main__":
    print "Start"
    f = open('/tmp/test_python','w')
    f.write('Hi there\n')
    f.close()
    print "End"